<!-- Advanced Form Start -->
<div class="advanced-form-area mg-b-15">
            <div class="container-fluid">
               <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="sparkline12-list mt-b-30">
                            <div class="sparkline12-hd">
                                <div class="main-sparkline12-hd">
                                    <h1>Edit Product</h1>
                                </div>
                            </div>
                            <div class="sparkline12-graph">
                                <div class="input-knob-dial-wrap">
<form class="form-horizontal style-form" method="POST" action="" enctype="multipart/form-data">

<div class="form-group-inner">
    <div class="row">
            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                <label class="login2 pull-right pull-right-pro" for="fk_shop_id">Show On Home Page</label>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
            <input type="checkbox" id="p_show_on_homepage" name="p_show_on_homepage" value="1" style="margin-left:-171px;" class="form-control" <?= $row['p_show_on_homepage'] == '1'?'checked':''; ?>  />
            </div>
        </div>
    </div>
<div class="form-group-inner">
    <div class="row">
            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                <label class="login2 pull-right pull-right-pro" for="fk_shop_id">Shop</label>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                <select id="fk_shop_id" name="fk_shop_id" class="form-control validate[required] text-input" onchange="get_category_from_shop(this.value);" >
                <option value="">Select Shop</option>
                <?php foreach($shop as $shoprow){ ?>
                <option value="<?= $shoprow['s_id']; ?>"  data-zoneid="<?=  $shoprow['fk_zone_id'];?>"   data-zonename="<?=  $shoprow['z_name'];?>"  <?= $row['fk_shop_id'] == $shoprow['s_id']?'selected':''; ?>><?= $shoprow['s_name']; ?></option>
                <?php } ?>                
                </select>
            </div>
        </div>
    </div>

    <div class="form-group-inner zone_section" >
    <div class="row">
            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">              
                <label class="login2 pull-right pull-right-pro" for="fk_shop_id">Zone Name</label>
            </div>
            <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
            <input type="text" id="zone_name" name="zone_name" class="form-control" readonly />
            <input type="hidden" id="fk_zone_id" name="fk_zone_id" class="form-control" readonly />
            </div>
            </div>
        </div>

    <div class="form-group-inner">
    <div class="row">
            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                <label class="login2 pull-right pull-right-pro" for="fk_category_id">Category</label>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                <select id="fk_category_id_o" name="fk_category_id" class="form-control validate[required] text-input" >
                <option value="">Select Category</option>                           
                </select>
            </div>
        </div>
    </div>

    <div class="form-group-inner">
    <div class="row">
            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                <label class="login2 pull-right pull-right-pro" for="p_name">Product Name</label>
            </div>
            <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
                <input type="text" id="p_name" name="p_name" class="form-control" placeholder="Enter Product Name" value="<?php if (isset($row['p_name'])) echo $row['p_name'] ?>"  />
            </div>
        </div>
    </div>
    
    <div class="form-group-inner">
    <div class="row">
            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                <label class="login2 pull-right pull-right-pro" for="p_amount">Amount</label>
            </div>
            <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
                <input type="number" id="p_amount" name="p_amount" class="form-control" onkeyup="javascript: return event.keyCode == 69 ? false : true" placeholder="Enter Amount"  value="<?php if (isset($row['p_amount'])) echo $row['p_amount'] ?>" />
            </div>
        </div>
    </div>

    <div class="form-group-inner">
    <div class="row">
            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                <label class="login2 pull-right pull-right-pro" for="p_market_amount">Market Amount</label>
            </div>
            <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
                <input type="number" id="p_market_amount" name="p_market_amount" class="form-control validate[required] text-input admin_profit_calculation" onchange="user_profit_calculation();" onkeyup="javascript: return event.keyCode == 69 ? false : true" placeholder="Enter Market Amount" value="<?php if (isset($row['p_market_amount'])) echo $row['p_market_amount'] ?>" />
            </div>
        </div>
    </div>


    <div class="form-group-inner">
    <div class="row">
            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                <label class="login2 pull-right pull-right-pro" for="p_buying_amount">Buying Amount</label>
            </div>
            <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
                <input type="number" id="p_buying_amount" name="p_buying_amount" class="form-control validate[required] text-input admin_profit_calculation" onchange="admin_profit_calculation();" onkeyup="javascript: return event.keyCode == 69 ? false : true" value="<?php if (isset($row['p_buying_amount'])) echo $row['p_buying_amount'] ?>" placeholder="Enter Buying Amount" />
            </div>
        </div>
    </div>


    <div class="form-group-inner">
    <div class="row">
            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                <label class="login2 pull-right pull-right-pro" for="p_admin_profit">Admin Profit</label>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                <input type="number" id="p_admin_profit" name="p_admin_profit" class="form-control validate[required] text-input p_admin_profit" onkeyup="javascript: return event.keyCode == 69 ? false : true" placeholder="Amount" value="<?php if (isset($row['p_admin_profit'])) echo $row['p_admin_profit'] ?>" readonly />
            </div>

            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                <label class="login2 pull-right pull-right-pro" for="p_user_profit">User Profit</label>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                <input type="number" id="p_user_profit" name="p_user_profit" class="form-control validate[required] text-input p_user_profit" onkeyup="javascript: return event.keyCode == 69 ? false : true" placeholder="Amount" value="<?php if (isset($row['p_user_profit'])) echo $row['p_user_profit'] ?>" readonly />
            </div>
    </div>
    </div>

    <div class="form-group-inner">
    <div class="row">
            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                <label class="login2 pull-right pull-right-pro" for="p_quantity">Quantity</label>
            </div>
            <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
                <input type="number" id="p_quantity" name="p_quantity" class="form-control" onkeyup="javascript: return event.keyCode == 69 ? false : true" placeholder="Enter Quantity"  value="<?php if (isset($row['p_quantity'])) echo $row['p_quantity'] ?>" />
            </div>
        </div>
    </div>

    <div class="form-group-inner">
    <div class="row">
            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                <label class="login2 pull-right pull-right-pro" for="p_thumbnail">Thumbnail</label>
            </div>
            <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
            <input type="hidden" id="bk_p_thumbnail" name="bk_p_thumbnail" value="<?php if (isset($row['p_thumbnail'])) echo $row['p_thumbnail'] ?>" />
                <input type="file" id="p_thumbnail" name="p_thumbnail" class="form-control" />
            </div>
        </div>
    </div>

    <div class="form-group-inner">
    <div class="row">
            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                <label class="login2 pull-right pull-right-pro" for="p_description">Description</label>
            </div>
            <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
                <textarea type="text" id="p_description" name="p_description" class="form-control" placeholder="Enter Description" ><?php if (isset($row['p_description'])) echo $row['p_description'] ?></textarea>
            </div>
        </div>
    </div>    
    <div class="row">

    <?php  foreach($productimg as $rowimg){ ?>      
                       
            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12" id="delete<?= $rowimg['pi_id']; ?>">
            <button class="btn btn-danger remove" type="button" onclick="deleterow(<?= $rowimg['pi_id']; ?>);"><i class="glyphicon glyphicon-remove"></i> </button>     
            <img src="<?php echo base_url().$rowimg['product_img'];?>" alt="Los Angeles" class="img-responsive img-thumbnail" style="width:200px;height:150px;">
            </div>                        
    <?php  }   ?>
    </div>   
    <div class="form-group-inner after-add-more">
    <div class="row">
            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                <label class="login2 pull-right pull-right-pro" for="p_quantity">Image</label>
            </div>
            <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
            <div class="control-group input-group" style="margin-top:10px">
            <input type="file" name="uploaded_file[]" class="form-control" placeholder="Enter Name Here">
            <div class="input-group-btn"> 
            <button class="btn btn-success add-more" type="button"><i class="glyphicon glyphicon-plus"></i> </button>
            </div>
          </div>
            </div>
        </div>
    </div> 

    <div class="form-group-inner">
        <div class="login-btn-inner">
            <div class="row">
                <div class="col-lg-2"></div>
                <div class="col-lg-9">
                    <div class="login-horizental cancel-wp pull-left form-bc-ele">
                        <button class="btn btn-sm btn-primary login-submit-cs" type="submit" name="update">Update</button>
                        <a href="<?= site_url();?>/view_product"><button class="btn btn-white" type="button">Cancel</button></a>                                                     
                    </div>
                </div>
            </div>
        </div>
    </div>
    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                
            </div>
        </div>
        <!-- Advanced Form End-->
        <div class="form-group-inner copy hide">
    <div class="row control-group">
            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                <label class="login2 pull-right pull-right-pro" for="p_quantity">Image</label>
            </div>
            <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
            <div class=" input-group" style="margin-top:10px">
            <input type="file" name="uploaded_file[]" class="form-control" placeholder="Enter Name Here">
            <div class="input-group-btn"> 
              <button class="btn btn-danger remove" type="button"><i class="glyphicon glyphicon-remove"></i> </button>
            </div>
          </div>
            </div>
        </div>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
<script>
        $( document ).ready(function() {
            get_category_from_shop($('#fk_shop_id').val());
        });

  function get_category_from_shop(fk_shop_id) {
    var fk_zone_id = $("#fk_shop_id option:selected").attr('data-zoneid');
        var zone_name = $("#fk_shop_id option:selected").attr('data-zonename');
        $.ajax({
            type: "post",
            url: "<?php echo site_url('/get_category_from_shop/') ?>",
            data: 'fk_shop_id=' + fk_shop_id,
            datatype: "text",
            success: function (data) {
                //alert(data);
                $(".zone_section").show('');
              $("#fk_zone_id").val(fk_zone_id);
              $("#zone_name").val(zone_name);
                $("#fk_category_id_o").html(data);
            }
        });
    }

    function deleterow(id){
         // alert(id);
        var deleteid = 'pi_id';
        var tdeletecolumn = 'pi_delete';     
        var tablename = 'product_img';      
        $.ajax({
            type: "post",
            url: "<?php echo site_url('/deleterow/') ?>",
            data: {id:id,deleteid:deleteid,tablename:tablename,tdeletecolumn:tdeletecolumn},
            datatype: "text",
            success: function(data){                
                if(data == 'success'){                    
                   $("#responsemsg").addClass("hide_respons");
                    $('#delete'+id).hide();
                    $('#responsemsg').show();
                    $('#responsemsg').html('Deleted Sucessfully.');
                }else{                    
                    $("#responsemsg").addClass("hide_respons");
                    $('#responsemsg').show();
                    $('#responsemsg').html('Error!');
                }            
            }
        });
    }

    function admin_profit_calculation() {    
        var p_buying_amount = $('#p_buying_amount').val();
        var p_selling_amount = $('#p_amount').val();       
        var admin_profit_calculation = p_selling_amount - p_buying_amount;
        console.log(admin_profit_calculation+'='+p_selling_amount+"-"+p_buying_amount);
        $('#p_admin_profit').val(admin_profit_calculation);
    }

    function user_profit_calculation() {
        var p_market_amount = $('#p_market_amount').val();      
        var p_selling_amount = $('#p_amount').val();
        
        var user_profit_calculation = p_market_amount - p_selling_amount;
        console.log(user_profit_calculation+"="+p_market_amount+"-"+p_selling_amount);
        $('#p_user_profit').val(user_profit_calculation);        
    }
</script>