	<?php 
	include_once 'floor_template/header.php';         
           
	echo $output;  
	include_once 'floor_template/footer.php'; 
	?>

